<?Php
$apiKey = "3c9c-3ae9-84f4-2db2";
$version = 2; // API version
$pin = "wsx258qaz";
$DVDOGaddress = "AFZnqZjvbsFba79FgLZCHcdMXvqpQYnKDS";
?>