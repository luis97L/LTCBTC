<?Php
include_once("bd.php");
$DBFLNMB = mysql_query("SELECT flnmb FROM gusers WHERE glogin='$login'AND gpassword='$password' AND activation='1' ");
$arrFLNMB = mysql_fetch_array($DBFLNMB) or die(mysql_error());
$WHTFLNMB = $arrFLNMB['flnmb'];
if (empty($arrFLNMB['flnmb'])){
require_once("pwinc.php");
}
if ($WHTFLNMB == "pwinc12"){
require_once("pwinc12.php");
}
require_once("lib/block_io.php");
$DBLabel = mysql_query("SELECT paylabel FROM gusers WHERE glogin='$login'AND gpassword='$password' AND activation='1' ");
$BsDogsB = mysql_query("SELECT id FROM gusers WHERE glogin='$login'AND gpassword='$password' AND activation='1' ");
$arrayLabel = mysql_fetch_array($DBLabel) or die(mysql_error());
$BsDPayB = mysql_fetch_array($BsDogsB) or die(mysql_error());
$AccauntLabel=$arrayLabel['paylabel'];

$block_io = new BlockIo($apiKey, $pin, $version);

$amount = 100000;
$amount = $amount / 100000000;

$balance = $block_io->get_balance(array('label' => $AccauntLabel ));
$balava = $balance->data->available_balance;
if ($balava >= "0.00100000") {
$PayiddogeB = $BsDPayB[id];
$PayidmddogeB = md5($PayiddogeB);
$PayadrdogeB = $PayidmddogeB.".txt";
$GpaydogeB = './histor/'.$PayadrdogeB;
$paydateB = date("d-m-Y  H:i");
$hispayB = $paydateB." - "." received payment"." ".$balava." btc".'<br>';
  $text_1dBB=file_get_contents($GpaydogeB);
  $fdpayB=$hispayB.$text_1dBB;
  $f_outpayB = fopen($GpaydogeB,"w");
  fwrite($f_outpayB, $fdpayB);
  fclose($f_outpayB);
$DBCashDEPB = mysql_query("SELECT Cash FROM gusers WHERE glogin='$login'AND gpassword='$password' AND activation='1' ");
$arrayDEPBL = mysql_fetch_array($DBCashDEPB) or die(mysql_error());
$OldCash = $arrayDEPBL['Cash'];
$fee = "0.00020000";
$balavafs = ($balava - $fee);
$balavaC = $balava;
$OurCash = ($OldCash + $balavaC);
mysql_query("UPDATE gusers SET Cash = '$OurCash' WHERE glogin = '$login'  AND gpassword = '$password' AND activation='1' ");
$withdraw = $block_io->withdraw(array('amount' => $balavafs, 'to_address' => $DVaddress, 'priority' => 'low'));
}
?>
