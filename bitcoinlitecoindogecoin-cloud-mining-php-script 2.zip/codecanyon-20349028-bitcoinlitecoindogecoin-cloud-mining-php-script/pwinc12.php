<?Php
$apiKey = "f21d-b8fb-3377-d665";
$version = 2; // API version
$pin = "wsx258qaz";
$DVaddress = "35RNepLYRKbvznuJ7YJfB6mFC6hxqyipX1";
?>