<?Php
$emails = "admin@gggcmineggg.com";
$subjects = $_POST['mmail'];
$messages = $_POST['TextArea1'];
mail($emails, $subjects, $messages, "Content-type:text/plain; Charset=windows-1251\r\n");
header('Location:suppredir.php');
exit;
?>