<?Php
ini_set('display_errors', 0);
error_reporting(0);
include_once("asdm.php");
if(empty($alogina) and empty($apassworda)){
require("mainentr.php");
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>TCC</title>
  <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
  	<link rel="shortcut icon" type="image/x-icon" href="ico/favicon.ico" />
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
     	    <style type="text/css">
<!--
@media only screen and ( max-width: 767px) {
#tableOUR{
font-size:7px;
}
}
@media only screen and ( max-width: 767px) and (-webkit-min-device-pixel-ratio: 1.5), only screen and (min--moz-device-pixel-ratio: 1.5), only screen and (min-resolution: 240dpi)  {
#tableOUR{
font-size:7px;
}
}
-->
    </style>
</head>
<body class="hold-transition skin-blue sidebar-mini">
<?php
$DBRATE = mysql_query("SELECT usdinbtc, dogeusd, ltcusd, dogebtc, ltcbtc FROM costsmc WHERE id='1' ");
$arrayRATE = mysql_fetch_array($DBRATE);
$usdinbtc = $arrayRATE['usdinbtc'];
$dogeusd = $arrayRATE['dogeusd'];
$ltcusd = $arrayRATE['ltcusd'];
$dogebtc = $arrayRATE['dogebtc'];
$ltcbtc = $arrayRATE['ltcbtc'];
?>
<div class="wrapper">
  <header class="main-header">
    <!-- Logo -->
    <a href="index.php" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>T</b>CC</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>TCC</b> ADMIN_PANEL</span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">

              <span class="hidden-xs"><?Php echo $alogina; ?></span>
            </a>
          </li>
          <!-- Control Sidebar Toggle Button -->
          <li>
            <a href="#" data-toggle="control-sidebar"><i class="fa fa-windows"></i></a>
          </li>
        </ul>
      </div>
    </nav>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu">
        <li class="header">MENU</li>
        <li>
          <a href="mainadm.php">
            <i class="fa fa-dashboard"></i> <span>GENERAL</span>
          </a>
        </li>
        <li class="active treeview">
          <a href="wthadm.php">
            <i class="fa fa-user"></i> <span>Withdraw</span>
          </a>
        </li>
        <li>
          <a href="depadm.php">
            <i class="fa fa-user"></i> <span>Deposit</span>
          </a>
        </li>
        <li>
          <a href="cstadm.php">
            <i class="fa fa-user"></i> <span>Clouds cost</span>
          </a>
        </li>
        <li>
          <a href="bnad.php">
            <i class="fa fa-user"></i> <span>Bonus</span>
          </a>
        </li>
          <li>
          <a href="pswrda.php">
            <i class="fa fa-book"></i> <span>Password</span>
          </a>
        </li>
        <li class="treeview">
          <a href="exit.php">
            <i class="fa fa-power-off"></i> <span>Signout</span>
          </a>
        </li>
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Withdraw
        <small>ADMIN_PANEL</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="mainadm.php"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">WITHDRAW</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
      <h2><a href="bitw.php">Pay Bitcoin </a></h2>
      <h2><a href="litew.php">Pay Litecoin </a></h2>
      <h2><a href="dogew.php">Pay Dogecoin </a></h2>
<br>
        <?Php
$DBWithBit = mysql_query("SELECT * FROM gusers WHERE amountwithdraw >= '0.00600000' ");
$DBWithDoge = mysql_query("SELECT * FROM ltcdoge WHERE amountwithdrawd >= '7000.00300000' ");
$DBWithLite = mysql_query("SELECT * FROM ltcdoge WHERE amountwithdrawl >= '0.40000000' ");
while ($AdminWB = mysql_fetch_array($DBWithBit))
{
$WithBdt = $AdminWB['datewithdraw'];
$WithBadr = $AdminWB['adresswithdraw'];
$WithBsum = $AdminWB['amountwithdraw'];
}
while ($AdminWD = mysql_fetch_array($DBWithDoge))
{
$WithDdt = $AdminWD['datewithdrawd'];
$WithDadr = $AdminWD['adresswithdrawd'];
$WithDsum = $AdminWD['amountwithdrawd'];
}
while ($AdminWL = mysql_fetch_array($DBWithLite))
{
$WithLdt = $AdminWL['datewithdrawl'];
$WithLadr = $AdminWL['adresswithdrawl'];
$WithLsum = $AdminWL['amountwithdrawl'];
}
echo "Bitcoin | ".$WithBdt." | ".$WithBadr." | ".$WithBsum."<br />\n";
echo "Dogecoin | ".$WithDdt." | ".$WithDadr." | ".$WithDsum."<br />\n";
echo "Litecoin | ".$WithLdt." | ".$WithLadr." | ".$WithLsum."<br />\n";
?>
</div>

      </div>
  </section>
  </div>
  <footer class="main-footer">
    <strong>Copyright &copy; 2017 <a href="#">TCC</a>.</strong> All rights
    reserved.
  </footer>
</div>
<!-- Bootstrap 3.3.6 -->
<script src="bootstrap/js/bootstrap.min.js"></script>
<!-- Slimscroll -->
<script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/app.min.js"></script>
</body>
</html>