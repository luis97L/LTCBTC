<script type="text/javascript">
      var dvsmhsp_month = 0;
      var delay_dvsmhsp = 100;
      var curdvsmhsp_earn  = 0;
      setInterval("stDvsmhsp()", delay_dvsmhsp);
      function stDvsmhsp() {
	  var divmydivt = document.divmy;
      var eamnhsp_eamn = document.form144.txtSumDHSP.value;
      var dvsmhsp_second = dvsmhsp_month / (30 * 24 * 3600);
      curdvsmhsp_earn += (dvsmhsp_second * delay_dvsmhsp / 1000);
	  var eamnhsp_now = (+eamnhsp_eamn + +curdvsmhsp_earn).toFixed(11);
      document.getElementById('labeldhsp').innerHTML = eamnhsp_now;
      }
      function Hspmup() {
      dvsmhsp_month = document.form112.earn_dhsp.value;
      curdvsmhsp_earn = eamnhsp_eamn;
	  }
</script>