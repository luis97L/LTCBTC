<!DOCTYPE HTML>
<html>
	<head>
		<title>TCC</title>
        <link rel="shortcut icon" type="image/x-icon" href="ico/favicon.ico" />
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
	</head>
		<div id="page-wrapper">

			<!-- Header -->
				<header id="header" class="alt">
					<h1 id="logo"><a href="main.html">TCC<span> Cloud mining cryptocurrency</span></a></h1>
					<nav id="nav">
						<ul>
							<li class="submenu">
								<a href="#">Menu</a>
								<ul>
									<li><a href="index.php">Main</a></li>
                                    <li><a href="faq.html">Faq</a></li>
                                    <li><a href="news.php">News</a></li>
								</ul>
							</li>
						</ul>
					</nav>
				</header>

			<!-- Banner -->
				<section id="banner">

					<!--
						".inner" is set up as an inline-block so it automatically expands
						in both directions to fit whatever's inside it. This means it won't
						automatically wrap lines, so be sure to use line breaks where
						appropriate (<br />).
					-->
					<div class="inner">

						<header>
							<h2>TCC mining</h2>
						</header>
       <div class="container">
      <div class="row mt">
      <div class="col-lg-8">
	        <h1>Support</h1>
	    <p><div id="Layer1">
							<div class="label-info">
<h3>Please use the form to describe your problem and enter your e-mail</h3>
<form name="Comments" method="post" action="supp.php" id="Form1">
<input name="mmail" type="email" id="mmail" class="form-control" placeholder = "e-mail" required><br>
<textarea name="TextArea1" id="TextArea1" style="border: 1px solid rgb(192, 192, 192); border-radius: 20px; width: 100%; height: 206px; font-family: Arial; font-size: 13px; " rows="5" cols="27"></textarea><br>
<input id="Button2" name="" value="Clear" style="border-radius: 10px;" type="reset">
<input type="submit" id="Button1" name="ButtonSend" value="Send" style="border-radius: 10px;">
</form>
			  </div>
		</div></p>
      	</div>
      </div><!-- /row -->
    </div><!-- /.container -->
						<footer>

						</footer>
					</div>

				</section>

			<!-- Footer -->
				<footer id="footer">

					<ul class="copyright">
						<li>&copy; 2017 TCC All Rights Reserved.</li>
					</ul>

				</footer>

		</div>

		<!-- Scripts -->
             <script>
               function look(type){
                param=document.getElementById(type);
                if(param.style.display == "none") param.style.display = "block";
                else param.style.display = "none"
             }
            </script>
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/jquery.scrollgress.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>