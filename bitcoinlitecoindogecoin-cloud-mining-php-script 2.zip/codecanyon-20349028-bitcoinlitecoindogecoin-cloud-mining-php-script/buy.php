<?php
include_once("bd.php");
if(empty($login) and empty($password)){
require("main.html");
}
include_once("incminingltcdog.php");
include_once("intmone.php");
include_once("initsmc.php");
?>

<!DOCTYPE html>
<html>
<head>

<script>
function Ftest (obj)
{
if (this.ST) return; var ov = obj.value;
var ovrl = ov.replace (/\d*\.?\d*/, '').length; this.ST = true;
if (ovrl > 0) {obj.value = obj.lang; Fshowerror (obj); return}
obj.lang = obj.value; this.ST = null;
}

function Fshowerror (obj)
{
if (!this.OBJ)
   {this.OBJ = obj; obj.style.backgroundColor = 'pink'; this.TIM = setTimeout (Fshowerror, 50)}
else
   {this.OBJ.style.backgroundColor = ''; clearTimeout (this.TIM); this.ST = null; Ftest (this.OBJ); this.OBJ = null}
}
</script>
<style type="text/css">
<!--
.стиль1 {color: #FF9933}
.стиль2 {color: #00CC99}
.стиль3 {color: #CCCCCC}
.стиль4 {color: #050505}
.стиль5 {color: #AA0000}
.стиль6 {color: #000000}
.стиль8 {color: #FFFFFF}
.стиль9 {color: #00C0EF}
-->
</style>
<style type="text/css">
@media only screen and ( max-width: 767px) {
#formBuy{
font-size:12px;
}
}
@media only screen and ( max-width: 767px) and (-webkit-min-device-pixel-ratio: 1.5), only screen and (min--moz-device-pixel-ratio: 1.5), only screen and (min-resolution: 240dpi)  {
#formBuy{
font-size:12px;
}
}

@media only screen and ( max-width: 767px) {
#frmMulty{
font-size:12px;
}
}
@media only screen and ( max-width: 767px) and (-webkit-min-device-pixel-ratio: 1.5), only screen and (min--moz-device-pixel-ratio: 1.5), only screen and (min-resolution: 240dpi)  {
#frmMulty{
font-size:12px;
}
}

@media only screen and ( max-width: 767px) {
#txtSumulty{
font-size:12px;
}
}
@media only screen and ( max-width: 767px) and (-webkit-min-device-pixel-ratio: 1.5), only screen and (min--moz-device-pixel-ratio: 1.5), only screen and (min-resolution: 240dpi)  {
#txtSumulty{
font-size:12px;
}
}
@media only screen and ( max-width: 767px) {
#formBuym{
font-size:12px;
}
}
@media only screen and ( max-width: 767px) and (-webkit-min-device-pixel-ratio: 1.5), only screen and (min--moz-device-pixel-ratio: 1.5), only screen and (min-resolution: 240dpi)  {
#formBuym{
font-size:12px;
}
}

@media only screen and ( max-width: 767px) {
#frmMultym{
font-size:12px;
}
}
@media only screen and ( max-width: 767px) and (-webkit-min-device-pixel-ratio: 1.5), only screen and (min--moz-device-pixel-ratio: 1.5), only screen and (min-resolution: 240dpi)  {
#frmMultym{
font-size:12px;
}
}

@media only screen and ( max-width: 767px) {
#txtSumultym{
font-size:12px;
}
}
@media only screen and ( max-width: 767px) and (-webkit-min-device-pixel-ratio: 1.5), only screen and (min--moz-device-pixel-ratio: 1.5), only screen and (min-resolution: 240dpi)  {
#txtSumultym{
font-size:12px;
}
}
@media only screen and ( max-width: 767px) {
#tablelittle{
font-size:12px;
}
}
@media only screen and ( max-width: 767px) and (-webkit-min-device-pixel-ratio: 1.5), only screen and (min--moz-device-pixel-ratio: 1.5), only screen and (min-resolution: 240dpi)  {
#tablelittle{
font-size:12px;
}
}
@media only screen and ( max-width: 767px) {
#tablelittlem{
font-size:12px;
}
}
@media only screen and ( max-width: 767px) and (-webkit-min-device-pixel-ratio: 1.5), only screen and (min--moz-device-pixel-ratio: 1.5), only screen and (min-resolution: 240dpi)  {
#tablelittlem{
font-size:12px;
}
}
@media only screen and ( max-width: 767px) {
#tablelittleDVS{
font-size:12px;
}
}
@media only screen and ( max-width: 767px) and (-webkit-min-device-pixel-ratio: 1.5), only screen and (min--moz-device-pixel-ratio: 1.5), only screen and (min-resolution: 240dpi)  {
#tablelittleDVS{
font-size:12px;
}
}
@media only screen and ( max-width: 767px) {
#textfield{
font-size:12px;
}
}
@media only screen and ( max-width: 767px) and (-webkit-min-device-pixel-ratio: 1.5), only screen and (min--moz-device-pixel-ratio: 1.5), only screen and (min-resolution: 240dpi)  {
#textfield{
font-size:12px;
}
}
</style>
  <style>
form.frmMulty{
    width: 100%;
    border: 3px solid #DD4B39;
    border-radius: 20px;
    background-color: #ECF0F5;
}
form.frmMultym{
    width: 100%;
    border: 3px solid #605CA8;
    border-radius: 20px;
    background-color: #ECF0F5;
}
  </style>
<style>
form.formBuy{
    width: 100%;
    border: 3px solid #00C0EF;
    border-radius: 20px;
    background-color: #ECF0F5;
}
form.formBuym{
    width: 100%;
    border: 3px solid #00C0EF;
    border-radius: 20px;
    background-color: #ECF0F5;
}
.стиль7 {font-size: None}
</style>
</head>

<body>
<div id="maincount">
     <p><a name="h500"></a></p>
          <div class="small-box bg-red">
            <div class="inner">
              <h4><div id="txtDVSm"></div></h4>

              <p>HASH-500m Price: <?Php echo " 1 Hash = ".$PriceBitD." BTC"; ?></p>
            </div>
            <div>
<form class="frmMulty" name="frmMulty" id= "frmMulty" method="post" action="">
  <tr>
    <td width="208" height="77" align="left" nowrap><h2 align="right">
      <label>
      <input name="txtIdbit" type="text" id="txtIdbit" value="<?Php echo $SumBuyF; ?>" hidden="hidden" >
      <input name="txtIddoge" type="text" id="txtIddoge" value="<?Php echo $CashDogeF; ?>" hidden="hidden" >
      <input name="txtIdlite" type="text" id="txtIdlite" value="<?Php echo $CashLiteF; ?>"  hidden="hidden" >
      </label>
    </h2>
          <input name="txtlabelv" type="text" id="txtlabelv" value="0000" hidden="hidden">
          <label>
        <input name="txtPrb" type="text" id="txtPrb" value="<?Php echo $PriceBitD; ?>" hidden="hidden" >
        <input name="txtPrd" type="text" id="txtPrd" value="<?Php echo $PriceDogeNF; ?>" hidden="hidden" >
        <input name="txtPrl" type="text" id="txtPrl" value="<?Php echo $PriceLtcNF; ?>" hidden="hidden">
        </label>

  </tr>
          <p align="center"><strong class="стиль4"><span class="стиль1">Cryptoc</span><span class="стиль3">urrency</span>
        <select name="slctCurrency" id="slctCurrency" style="background-color:transparent; border-radius: 7px; border-color:#A185AD;" onChange="GetData(); fn();"> </strong>
		  <option value="Doge" style="color:#FF9933;">Dogecoin</option>
          <option value="Lite" style="color:#777777;">Litecoin</option>
          <option value="Bit" style="color:#007A00;">Bitcoin</option>
          </select>
          <input name="txtSumulty" id= "txtSumulty" type="text" checked="checked" value="<?Php echo $CashDogeF; ?>" oninput="Ftest (this)"
       onpropertychange="if ('v' == '\v' && parseFloat (navigator.userAgent.split ('MSIE ') [1].split (';') [0]) <= 9) Ftest (this)"  value=<?php echo $SumBuy;  ?> size="35" Style = "border-radius: 10px;" placeholder="0.00000000" required >
          <input name="CalcBuy" type="button" value="Quick calculate " title="QUICK CALCULATE" onClick="GetCalc();" Style = "border-radius: 10px;"  >
		  </td>
        </p>
  </div>
  <tr>
    <td width="100%" height="77">
      <h3 align="right">&nbsp;</h3>
    </td>
     </td>
  </tr>
  </label>
<table width="100%" border="3"  id="tablelittle">
     <tr>
      <th scope="row">&nbsp;</th>
      <td class="frmMulty"><div align="center" class="стиль1 стиль7">Doge</div></td>
      <td><div align="center" class="стиль2">Bitcoin</div></td>
      <td><div align="center" class="стиль3">Ltc</div></td>
    </tr>
    <tr>
      <th width="25%" scope="row"><div align="left" class="стиль6">per day </div></th>
      <td width="25%"><div align="center" class="стиль1" id="TLdayD">0.00000000</div></td>
      <td width="25%"><div align="center" class="стиль2" id="TBitday">0.00000000</div></td>
      <div style="display:none;" id="TLDVSm">0.00000000</div>
      <td width="25%"><div align="center" class="стиль3" id="TLdayL">0.00000000</div></td>
    </tr>
    <tr>
      <th scope="row"><div align="left" class="стиль6">per month </div></th>
      <td class="frmMulty"><div align="center" class="стиль1 стиль7" id="TLmonthD">0.00000000</div></td>
      <td><div align="center" class="стиль2" id="TBitmonth">0.00000000</div></td>
      <td><div align="center" class="стиль3" id="TLmonthL">0.00000000</div></td>
    </tr>
    <tr>
      <th scope="row"><div align="left" class="стиль6">per year </div></th>
      <td class="frmMulty"><div align="center" class="стиль1 стиль7" id="TLyearD">0.00000000</div></td>
       <td><div align="center" class="стиль2" id="TBityear">0.00000000</div></td>
      <td><div align="center" class="стиль3" id="TLyearL">0.00000000</div></td>
    </tr>
    <tr>
      <th scope="row"><div align="left" class="стиль6">per three years </div></th>
      <td class="frmMulty"><div align="center" class="стиль1 стиль7" id="TLthreeD">0.00000000</div></td>
      <td><div align="center" class="стиль2" id="TBthreey">0.00000000</div></td>
      <td><div align="center" class="стиль3" id="TLthreeL">0.00000000</div></td>
    </tr>
  </table>
            <br>
            <div class="icon">
              <i class="ion ion-cloud"></i>
            </div>
            <div align="center" class="small-box-footer">
            <input type="submit" id="BuyMulty" name="BuyMulty" value="Buy" Style="border-radius: 10px;"/>  <i class="fa fa-cloud-upload"></i>
            </form>
            </div>
          </div>
         <p><a name="h300"></a></p>
           <div class="small-box bg-purple">
            <div class="inner">
              <h4><div id="txtDVSmm"></div></h4>

              <p>HASH-300m Price: <?Php echo " 1 Hash = ".$PriceBitCDm." BTC"; ?></p>
            </div>
                        <div>
<form class="frmMultym" name="frmMultym" id= "frmMultym" method="post" action="">
  <tr>
    <td width="208" height="77" align="left" nowrap><h2 align="right">
      <label>
      <input name="txtIdbitm" type="text" id="txtIdbitm" value="<?Php echo $SumBuyF; ?>" hidden>
      <input name="txtIddogem" type="text" id="txtIddogem" value="<?Php echo $CashDogeF; ?>" hidden>
      <input name="txtIdlitem" type="text" id="txtIdlitem" value="<?Php echo $CashLiteF; ?>" hidden>
      </label>
    </h2>
          <input name="txtlabelvm" type="text" id="txtlabelvm" value="0000" hidden>
          <label>
        <input name="txtPrbm" type="text" id="txtPrbm" value="<?Php echo $PriceBitCDm; ?>" hidden>
        <input name="txtPrdm" type="text" id="txtPrdm" value="<?Php echo $PriceDogeNFm; ?>" hidden>
        <input name="txtPrlm" type="text" id="txtPrlm" value="<?Php echo $PriceLtcNFm; ?>" hidden>
        </label>

  </tr>
          <p align="center"><strong class="стиль4"><span class="стиль1">Cryptoc</span><span class="стиль3">urrency</span>
        <select name="slctCurrencym" id="slctCurrencym" style="background-color:transparent; border-radius: 7px; border-color:#A185AD;" onChange="GetDatam(); fn();"> </strong>
		  <option value="Doge" style="color:#FF9933;">Dogecoin</option>
          <option value="Lite" style="color:#777777;">Litecoin</option>
          <option value="Bit" style="color:#007A00;">Bitcoin</option>
          </select>
          <input name="txtSumultym" id= "txtSumultym" type="text" checked="checked" value="<?Php echo $CashDogeF; ?>" oninput="Ftest (this)"
       onpropertychange="if ('v' == '\v' && parseFloat (navigator.userAgent.split ('MSIE ') [1].split (';') [0]) <= 9) Ftest (this)"  value=<?php echo $SumBuy;  ?> size="35" Style = "border-radius: 10px;" placeholder="0.00000000" required >
          <input name="CalcBuym" type="button" value="Quick calculate " title="QUICK CALCULATE" onClick="GetCalcm();" Style = "border-radius: 10px;"  >
		  </td>
        </p>
  </div>
  <tr>
    <td width="100%" height="77">
      <h3 align="right">&nbsp;</h3>
    </td>
     </td>
  </tr>
  </label>
<table width="100%" border="3"  id="tablelittlem">
     <tr>
      <th scope="row">&nbsp;</th>
      <td class="frmMultym"><div align="center" class="стиль1 стиль7">Doge</div></td>
      <td><div align="center" class="стиль2">Bitcoin</div></td>
      <td><div align="center" class="стиль3">Ltc</div></td>
    </tr>
    <tr>
      <th width="25%" scope="row"><div align="left" class="стиль6">per day </div></th>
      <td width="25%"><div align="center" class="стиль1" id="TLdayDm">0.00000000</div></td>
      <td width="25%"><div align="center" class="стиль2" id="TBitdaym">0.00000000</div></td>
      <div style="display:none;" id="TLDVSmm">0.00000000</div>
      <td width="25%"><div align="center" class="стиль3" id="TLdayLm">0.00000000</div></td>
    </tr>
    <tr>
      <th scope="row"><div align="left" class="стиль6">per month </div></th>
      <td class="frmMultym"><div align="center" class="стиль1 стиль7" id="TLmonthDm">0.00000000</div></td>
      <td><div align="center" class="стиль2" id="TBitmonthm">0.00000000</div></td>
      <td><div align="center" class="стиль3" id="TLmonthLm">0.00000000</div></td>
    </tr>
    <tr>
      <th scope="row"><div align="left" class="стиль6">per year </div></th>
      <td class="frmMultym"><div align="center" class="стиль1 стиль7" id="TLyearDm">0.00000000</div></td>
       <td><div align="center" class="стиль2" id="TBityearm">0.00000000</div></td>
      <td><div align="center" class="стиль3" id="TLyearLm">0.00000000</div></td>
    </tr>
    <tr>
      <th scope="row"><div align="left" class="стиль6">per three years </div></th>
      <td class="frmMultym"><div align="center" class="стиль1 стиль7" id="TLthreeDm">0.00000000</div></td>
      <td><div align="center" class="стиль2" id="TBthreeym">0.00000000</div></td>
      <td><div align="center" class="стиль3" id="TLthreeLm">0.00000000</div></td>
    </tr>
  </table>
            <br>
            <div class="icon">
              <i class="ion ion-cloud"></i>
            </div>
            <div align="center" class="small-box-footer">
            <input type="submit" id="BuyMultym" name="BuyMultym" value="Buy" Style="border-radius: 10px;"/>  <i class="fa fa-cloud-upload"></i>
            </form>
            </div>
          </div>
          <p><a name="h700"></a></p>
          <div class="small-box bg-aqua">
            <div class="inner">
              <h4><div id="txtDVSDVS"></div></h4>

              <p>HASH-700mx Price: <?Php echo " 1 Hash = ".$hashseven." BTC"; ?></p>
            </div>
            <div>
<form class="formBuy" name="formBuy" id="formBuy" method="post" action="">
  <tr>
    <td width="208" height="77" align="left" nowrap><h2 align="right">
      <label>
      <input name="txtIdbitDVS" type="text" id="txtIdbitDVS" value="<?Php echo $SumBuyF; ?>" hidden>
      </label>
    </h2>
          <input name="txtlabelvDVS" type="text" id="txtlabelvDVS" value="Bitc" hidden>
          <label>
        <input name="txtPrbDVS" type="text" id="txtPrbDVS" value="<?Php echo $hashseven; ?>" hidden>
        </label>

  </tr>
          <p align="center"><strong class="стиль4"><span class="стиль9">Bitcion</span>
       <input name="textfield" id = "textfield" type="text" checked="checked" oninput="Ftest (this)"
       onpropertychange="if ('v' == '\v' && parseFloat (navigator.userAgent.split ('MSIE ') [1].split (';') [0]) <= 9) Ftest (this)"  value=<?php echo $xcSum = number_format($SumBuy,8,'.','');  ?> size="35" maxlength="13" Style = "border-radius: 10px;" placeholder="0.00000000" required >
          <input name="CalcBuym" type="button" value="Quick calculate " title="QUICK CALCULATE" onClick="GetCalcBIT();" Style = "border-radius: 10px;"  >
		  </td>
        </p>
  </div>
  <tr>
    <td width="100%" height="77">
      <h3 align="right">&nbsp;</h3>
    </td>
     </td>
  </tr>
  </label>
<table width="100%" border="3"  id="tablelittleDVS">
     <tr>
      <th scope="row">&nbsp;</th>
      <td class="formBuy"><div align="center" class="стиль8">Bitcoin</div></td>
    </tr>
    <tr>
      <th width="25%" scope="row"><div align="left" class="стиль6">per day </div></th>
      <td width="75%"><div align="center" class="стиль8" id="TBitdayDVS">0.00000000</div></td>
      <div style="display:none;" id="TLDVSDVS">0.00000000</div>
    </tr>
    <tr>
      <th scope="row"><div align="left" class="стиль6">per month </div></th>
      <td class="formBuy"><div align="center" class="стиль8" id="TBitmonthDVS">0.00000000</div></td>
    </tr>
    <tr>
      <th scope="row"><div align="left" class="стиль6">per year </div></th>
      <td class="formBuy"><div align="center" class="стиль8" id="TBityearDVS">0.00000000</div></td>
    </tr>
    <tr>
      <th scope="row"><div align="left" class="стиль6">per three years </div></th>
      <td class="formBuy"><div align="center" class="стиль8" id="TBthreeyDVS">0.00000000</div></td>
    </tr>
  </table>
            <br>

            <div class="icon">
              <i class="ion ion-cloud"></i>
            </div>
             <div align="center" class="small-box-footer">
            <input type="submit" id="SubmitCalc" name="SubmitCalc" value="Buy" Style="border-radius: 10px;"/>  <i class="fa fa-cloud-upload"></i>
             </form>
            </div>
          </div>
</div>
 <script type="text/javascript">
  function GetData()
  {
  var sum_bit = document.frmMulty.txtIdbit.value;
  var sum_doge = document.frmMulty.txtIddoge.value;
  var sum_lite = document.frmMulty.txtIdlite.value;
  var pr_bit = document.frmMulty.txtPrb.value;
  var pr_doge = document.frmMulty.txtPrd.value;
  var pr_lite = document.frmMulty.txtPrl.value;
  	 var selind = document.getElementById("slctCurrency").options.selectedIndex;
	  var txt= document.getElementById("slctCurrency").options[selind].text;
   var val= document.getElementById("slctCurrency").options[selind].value;
     var znak= document.getElementById("txtlabelv").value = val;
     	 if (znak == "Doge") {
	 document.getElementById("txtSumulty").value = sum_doge;
	 var cur_doge = (+sum_doge / +pr_doge).toFixed(8);
	  document.getElementById("txtDVSm").innerHTML = cur_doge;
	  document.getElementById("TLDVSm").innerHTML = cur_doge;
	 var per_month = (+sum_doge /3.2).toFixed(8);
	 var per_year = (+per_month * 12).toFixed(8);
	 var per_three = (+per_year * 3).toFixed(8);
	 var per_day = (+per_month / 30).toFixed(8);
     var per_bitmonth = (+(+cur_doge * pr_bit) / 3.2).toFixed(8);
     var per_bityear = (+per_bitmonth * 12).toFixed(8);
     var per_bitthree = (+per_bityear * 3).toFixed(8);
     var per_bitdayb = (+per_bitmonth / 30).toFixed(8);
	 var per_lm = (+(+cur_doge * +pr_lite) / 3.2).toFixed(8);
	 var per_ly = (+per_lm * 12).toFixed(8);
	 var per_lt = (+per_ly *3).toFixed(8);
	 var per_ld = (+per_lm / 30).toFixed(8);
	 document.getElementById("TLdayD").innerHTML = per_day;
	 document.getElementById("TLmonthD").innerHTML = per_month;
	 document.getElementById("TLyearD").innerHTML = per_year;
	 document.getElementById("TLthreeD").innerHTML = per_three;
     document.getElementById("TBitmonth").innerHTML = per_bitmonth;
     document.getElementById("TBityear").innerHTML = per_bityear;
     document.getElementById("TBthreey").innerHTML = per_bitthree;
     document.getElementById("TBitday").innerHTML = per_bitdayb;
	  document.getElementById("TLdayL").innerHTML = per_ld;
	 document.getElementById("TLmonthL").innerHTML = per_lm;
	 document.getElementById("TLyearL").innerHTML = per_ly;
	 document.getElementById("TLthreeL").innerHTML = per_lt;
	 }
	  if (znak == "Bit") {
	 document.getElementById("txtSumulty").value = sum_bit;
	 var cur_bit = (+sum_bit / +pr_bit).toFixed(8);
	 document.getElementById("txtDVSm").innerHTML = cur_bit;
	 document.getElementById("TLDVSm").innerHTML = cur_bit;
	 var per_mbitdoge = (+(+cur_bit * +pr_doge) / 3.2).toFixed(8);
	 var per_ybitdoge = (+per_mbitdoge * 12).toFixed(8);
	 var per_tbitdoge = (+per_ybitdoge *3).toFixed(8);
	 var per_dbitdoge = (+per_mbitdoge / 30).toFixed(8);
     var per_bibitm = (+sum_bit / 3.2).toFixed(8);
     var per_bibity = (+per_bibitm * 12).toFixed(8);
     var per_bibitthree = (+per_bibity * 3).toFixed(8);
     var per_bibitday = (+per_bibitm / 30).toFixed(8);
	 var per_mbitlite = (+(+cur_bit * +pr_lite) / 3.2).toFixed(8);
	 var per_ybitlite = (+per_mbitlite * 12).toFixed(8);
	 var per_tbitlite = (+per_ybitlite *3).toFixed(8);
	 var per_dbitlite = (+per_mbitlite / 30).toFixed(8);
	 document.getElementById("TLdayD").innerHTML = per_dbitdoge;
	 document.getElementById("TLmonthD").innerHTML = per_mbitdoge;
	 document.getElementById("TLyearD").innerHTML = per_ybitdoge;
	 document.getElementById("TLthreeD").innerHTML = per_tbitdoge;
     document.getElementById("TBitmonth").innerHTML = per_bibitm;
     document.getElementById("TBityear").innerHTML = per_bibity;
     document.getElementById("TBthreey").innerHTML = per_bibitthree;
     document.getElementById("TBitday").innerHTML = per_bibitday;
	 document.getElementById("TLdayL").innerHTML = per_dbitlite;
	 document.getElementById("TLmonthL").innerHTML = per_mbitlite;
	 document.getElementById("TLyearL").innerHTML = per_ybitlite;
	 document.getElementById("TLthreeL").innerHTML = per_tbitlite;
	 }
	  if (znak == "Lite") {
	 document.getElementById("txtSumulty").value = sum_lite;
	 var cur_lite = (+sum_lite / +pr_lite).toFixed(8);
	  document.getElementById("txtDVSm").innerHTML = cur_lite;
	  document.getElementById("TLDVSm").innerHTML = cur_lite;
	 var per_monthL = (+sum_lite /3.2).toFixed(8);
	 var per_yearL = (+per_monthL * 12).toFixed(8);
	 var per_threeL = (+per_yearL * 3).toFixed(8);
	 var per_dayL = (per_monthL / 30).toFixed(8);
     var per_bitlim = (+(+cur_lite * +pr_bit) / 3.2).toFixed(8);
     var per_bitliy = (+per_bitlim * 12).toFixed(8);
     var per_bitlithree = (+per_bitliy * 3).toFixed(8);
     var per_bitliday = (+per_bitlim / 30).toFixed(8);
	 var per_dm = (+(+cur_lite * +pr_doge) / 3.2).toFixed(8);
	 var per_dy = (+per_dm * 12).toFixed(8);
	 var per_dt = (+per_dy *3).toFixed(8);
	 var per_dd = (+per_dm / 30).toFixed(8);
	  document.getElementById("TLdayL").innerHTML = per_dayL;
	 document.getElementById("TLmonthL").innerHTML = per_monthL;
	 document.getElementById("TLyearL").innerHTML = per_yearL;
	 document.getElementById("TLthreeL").innerHTML = per_threeL;
     document.getElementById("TBitmonth").innerHTML = per_bitlim;
     document.getElementById("TBityear").innerHTML = per_bitliy;
     document.getElementById("TBthreey").innerHTML = per_bitlithree;
     document.getElementById("TBitday").innerHTML = per_bitliday;
	 document.getElementById("TLdayD").innerHTML = per_dd;
	 document.getElementById("TLmonthD").innerHTML = per_dm;
	 document.getElementById("TLyearD").innerHTML =  per_dy;
	 document.getElementById("TLthreeD").innerHTML = per_dt;
	 }
  }
        </script>
      <script type="text/javascript">
  function GetDatam()
  {
  var sum_bitm = document.frmMultym.txtIdbitm.value;
  var sum_dogem = document.frmMultym.txtIddogem.value;
  var sum_litem = document.frmMultym.txtIdlitem.value;
  var pr_bitm = document.frmMultym.txtPrbm.value;
  var pr_dogem = document.frmMultym.txtPrdm.value;
  var pr_litem = document.frmMultym.txtPrlm.value;
  	 var selindm = document.getElementById("slctCurrencym").options.selectedIndex;
	  var txtm= document.getElementById("slctCurrencym").options[selindm].text;
   var valm= document.getElementById("slctCurrencym").options[selindm].value;
     var znakm= document.getElementById("txtlabelvm").value = valm;
     	 if (znakm == "Doge") {
	 document.getElementById("txtSumultym").value = sum_dogem;
	 var cur_dogem = (+sum_dogem / +pr_dogem).toFixed(8);
	  document.getElementById("txtDVSmm").innerHTML = cur_dogem;
	  document.getElementById("TLDVSmm").innerHTML = cur_dogem;
	 var per_monthm = (+sum_dogem /3.1).toFixed(8);
	 var per_yearm = (+per_monthm * 12).toFixed(8);
	 var per_threem = (+per_yearm * 3).toFixed(8);
	 var per_daym = (+per_monthm / 30).toFixed(8);
     var per_bitmonthm = (+(+cur_dogem* pr_bitm) / 3.1).toFixed(8);
     var per_bityearm = (+per_bitmonthm * 12).toFixed(8);
     var per_bitthreem = (+per_bityearm * 3).toFixed(8);
     var per_bitdaybm = (+per_bitmonthm / 30).toFixed(8);
	 var per_lmm = (+(+cur_dogem * +pr_litem) / 3.1).toFixed(8);
	 var per_lym = (+per_lmm * 12).toFixed(8);
	 var per_ltm = (+per_lym *3).toFixed(8);
	 var per_ldm = (+per_lmm / 30).toFixed(8);
	 document.getElementById("TLdayDm").innerHTML = per_daym;
	 document.getElementById("TLmonthDm").innerHTML = per_monthm;
	 document.getElementById("TLyearDm").innerHTML = per_yearm;
	 document.getElementById("TLthreeDm").innerHTML = per_threem;
     document.getElementById("TBitmonthm").innerHTML = per_bitmonthm;
     document.getElementById("TBityearm").innerHTML = per_bityearm;
     document.getElementById("TBthreeym").innerHTML = per_bitthreem;
     document.getElementById("TBitdaym").innerHTML = per_bitdaybm;
	  document.getElementById("TLdayLm").innerHTML = per_ldm;
	 document.getElementById("TLmonthLm").innerHTML = per_lmm;
	 document.getElementById("TLyearLm").innerHTML = per_lym;
	 document.getElementById("TLthreeLm").innerHTML = per_ltm;
	 }
	  if (znakm == "Bit") {
	 document.getElementById("txtSumultym").value = sum_bitm;
	 var cur_bitm = (+sum_bitm / +pr_bitm).toFixed(8);
	 document.getElementById("txtDVSmm").innerHTML = cur_bitm;
	 document.getElementById("TLDVSmm").innerHTML = cur_bitm;
	 var per_mbitdogem = (+(+cur_bitm * +pr_dogem) / 3.1).toFixed(8);
	 var per_ybitdogem = (+per_mbitdogem * 12).toFixed(8);
	 var per_tbitdogem = (+per_ybitdogem *3).toFixed(8);
	 var per_dbitdogem = (+per_mbitdogem / 30).toFixed(8);
     var per_bibitmm = (+sum_bitm / 3.1).toFixed(8);
     var per_bibitym = (+per_bibitmm * 12).toFixed(8);
     var per_bibitthreem = (+per_bibitym * 3).toFixed(8);
     var per_bibitdaym = (+per_bibitmm / 30).toFixed(8);
	 var per_mbitlitem = (+(+cur_bitm * +pr_litem) / 3.1).toFixed(8);
	 var per_ybitlitem = (+per_mbitlitem * 12).toFixed(8);
	 var per_tbitlitem = (+per_ybitlitem *3).toFixed(8);
	 var per_dbitlitem = (+per_mbitlitem / 30).toFixed(8);
	 document.getElementById("TLdayDm").innerHTML = per_dbitdogem;
	 document.getElementById("TLmonthDm").innerHTML = per_mbitdogem;
	 document.getElementById("TLyearDm").innerHTML = per_ybitdogem;
	 document.getElementById("TLthreeDm").innerHTML = per_tbitdogem;
     document.getElementById("TBitmonthm").innerHTML = per_bibitmm;
     document.getElementById("TBityearm").innerHTML = per_bibitym;
     document.getElementById("TBthreeym").innerHTML = per_bibitthreem;
     document.getElementById("TBitdaym").innerHTML = per_bibitdaym;
	 document.getElementById("TLdayLm").innerHTML = per_dbitlitem;
	 document.getElementById("TLmonthLm").innerHTML = per_mbitlitem;
	 document.getElementById("TLyearLm").innerHTML = per_ybitlitem;
	 document.getElementById("TLthreeLm").innerHTML = per_tbitlitem;
	 }
	  if (znakm == "Lite") {
	 document.getElementById("txtSumultym").value = sum_litem;
	 var cur_litem = (+sum_litem / +pr_litem).toFixed(8);
	  document.getElementById("txtDVSmm").innerHTML = cur_litem;
	  document.getElementById("TLDVSmm").innerHTML = cur_litem;
	 var per_monthLm = (+sum_litem /3.1).toFixed(8);
	 var per_yearLm = (+per_monthLm * 12).toFixed(8);
	 var per_threeLm = (+per_yearLm * 3).toFixed(8);
	 var per_dayLm = (per_monthLm / 30).toFixed(8);
     var per_bitlimm = (+(+cur_litem * +pr_bitm) / 3.1).toFixed(8);
     var per_bitliym = (+per_bitlimm * 12).toFixed(8);
     var per_bitlithreem = (+per_bitliym * 3).toFixed(8);
     var per_bitlidaym = (+per_bitlimm / 30).toFixed(8);
	 var per_dmm = (+(+cur_litem * +pr_dogem) / 3.1).toFixed(8);
	 var per_dym = (+per_dmm * 12).toFixed(8);
	 var per_dtm = (+per_dym *3).toFixed(8);
	 var per_ddm = (+per_dmm / 30).toFixed(8);
	  document.getElementById("TLdayLm").innerHTML = per_dayLm;
	 document.getElementById("TLmonthLm").innerHTML = per_monthLm;
	 document.getElementById("TLyearLm").innerHTML = per_yearLm;
	 document.getElementById("TLthreeLm").innerHTML = per_threeLm;
     document.getElementById("TBitmonthm").innerHTML = per_bitlimm;
     document.getElementById("TBityearm").innerHTML = per_bitliym;
     document.getElementById("TBthreeym").innerHTML = per_bitlithreem;
     document.getElementById("TBitdaym").innerHTML = per_bitlidaym;
	 document.getElementById("TLdayDm").innerHTML = per_ddm;
	 document.getElementById("TLmonthDm").innerHTML = per_dmm;
	 document.getElementById("TLyearDm").innerHTML =  per_dym;
	 document.getElementById("TLthreeDm").innerHTML = per_dtm;
	 }
  }
        </script>
  <script type="text/javascript">
  function GetDataDVS()
  {
  var sum_bitdvs = document.formBuy.txtIdbitDVS.value;
  var pr_bitdvs = document.formBuy.txtPrbDVS.value;
  var znakdvs= document.getElementById("txtlabelvDVS").value = "Bitc";
     if (znakdvs == "Bitc") {
	 document.getElementById("textfield").value = sum_bitdvs;
	 var cur_bitdvs = (+sum_bitdvs / +pr_bitdvs).toFixed(8);
	 document.getElementById("txtDVSDVS").innerHTML = cur_bitdvs;
	 document.getElementById("TLDVSDVS").innerHTML = cur_bitdvs;
     var per_bibitmdvs = (+sum_bitdvs / 2.9).toFixed(8);
     var per_bibitydvs = (+per_bibitmdvs * 12).toFixed(8);
     var per_bibitthreedvs = (+per_bibitydvs * 3).toFixed(8);
     var per_bibitdaydvs = (+per_bibitmdvs / 30).toFixed(8);
     document.getElementById("TBitmonthDVS").innerHTML = per_bibitmdvs;
     document.getElementById("TBityearDVS").innerHTML = per_bibitydvs;
     document.getElementById("TBthreeyDVS").innerHTML = per_bibitthreedvs;
     document.getElementById("TBitdayDVS").innerHTML = per_bibitdaydvs;
  }
  }
  </script>
          <script type="text/javascript">
 function GetCalc()
  {
  var sum_calc = document.frmMulty.txtSumulty.value;
  var pr_bitcalc = document.frmMulty.txtPrb.value;
  var pr_dogecalc = document.frmMulty.txtPrd.value;
  var pr_litecalc = document.frmMulty.txtPrl.value;
  var selindcalc = document.getElementById("slctCurrency").options.selectedIndex;
  var txtcalc= document.getElementById("slctCurrency").options[selindcalc].text;
  var valcalc= document.getElementById("slctCurrency").options[selindcalc].value;
  var znakcalc= document.getElementById("txtlabelv").value = valcalc;
   if (znakcalc == "Doge") {
	 var cur_dogecalc = (+sum_calc / +pr_dogecalc).toFixed(8);
	  document.getElementById("txtDVSm").innerHTML = cur_dogecalc;
	  document.getElementById("TLDVSm").innerHTML = cur_dogecalc;
	 var per_monthcalc = (+sum_calc /3.2).toFixed(8);
	 var per_yearcalc = (+per_monthcalc * 12).toFixed(8);
	 var per_threecalc = (+per_yearcalc * 3).toFixed(8);
	 var per_daycalc = (+per_monthcalc / 30).toFixed(8);
     var per_bitmonthclc = (+(+cur_dogecalc * +pr_bitcalc) / 3.2).toFixed(8);
     var per_bityclc = (+per_bitmonthclc * 12).toFixed(8);
     var per_bittclc = (+per_bityclc * 3).toFixed(8);
     var per_bitdclc = (+per_bitmonthclc / 30).toFixed(8);
	 var per_lmcalc = (+(+cur_dogecalc * +pr_litecalc) / 3.2).toFixed(8);
	 var per_lycalc = (+per_lmcalc * 12).toFixed(8);
	 var per_ltcalc = (+per_lycalc *3).toFixed(8);
	 var per_ldcalc = (+per_lmcalc / 30).toFixed(8);
	 document.getElementById("TLdayD").innerHTML = per_daycalc;
	 document.getElementById("TLmonthD").innerHTML = per_monthcalc;
	 document.getElementById("TLyearD").innerHTML = per_yearcalc;
	 document.getElementById("TLthreeD").innerHTML = per_threecalc;
     document.getElementById("TBitmonth").innerHTML = per_bitmonthclc;
     document.getElementById("TBityear").innerHTML = per_bityclc;
     document.getElementById("TBthreey").innerHTML = per_bittclc;
     document.getElementById("TBitday").innerHTML = per_bitdclc;
	  document.getElementById("TLdayL").innerHTML = per_ldcalc;
	 document.getElementById("TLmonthL").innerHTML = per_lmcalc;
	 document.getElementById("TLyearL").innerHTML = per_lycalc;
	 document.getElementById("TLthreeL").innerHTML = per_ltcalc;
	 }
	  if (znakcalc == "Lite") {
	 var cur_litecalc = (+sum_calc / +pr_litecalc).toFixed(8);
	  document.getElementById("txtDVSm").innerHTML = cur_litecalc;
	  document.getElementById("TLDVSm").innerHTML = cur_litecalc;
     var per_dmcalc = (+(+cur_litecalc * +pr_dogecalc) / 3.2).toFixed(8);
	 var per_dycalc = (+per_dmcalc * 12).toFixed(8);
	 var per_dtcalc = (+per_dycalc *3).toFixed(8);
	 var per_ddcalc = (+per_dmcalc / 30).toFixed(8);
     var per_bitmliclc = (+(+cur_litecalc * +pr_bitcalc) / 3.2).toFixed(8);
     var per_bityliclc = (+per_bitmliclc * 12).toFixed(8);
     var per_bittliclc = (+per_bityliclc * 3).toFixed(8);
     var per_bitdliclc = (+per_bitmliclc / 30).toFixed(8);
     var per_monthLcalc = (+sum_calc /3.2).toFixed(8);
	 var per_yearLcalc = (+per_monthLcalc * 12).toFixed(8);
	 var per_threeLcalc = (+per_yearLcalc * 3).toFixed(8);
	 var per_dayLcalc = (per_monthLcalc / 30).toFixed(8);
     document.getElementById("TLdayD").innerHTML = per_ddcalc;
	 document.getElementById("TLmonthD").innerHTML = per_dmcalc;
	 document.getElementById("TLyearD").innerHTML = per_dycalc;
	 document.getElementById("TLthreeD").innerHTML = per_dtcalc;
     document.getElementById("TBitmonth").innerHTML = per_bitmliclc;
     document.getElementById("TBityear").innerHTML = per_bityliclc;
     document.getElementById("TBthreey").innerHTML = per_bittliclc;
     document.getElementById("TBitday").innerHTML = per_bitdliclc;
	 document.getElementById("TLdayL").innerHTML = per_dayLcalc;
	 document.getElementById("TLmonthL").innerHTML = per_monthLcalc;
	 document.getElementById("TLyearL").innerHTML = per_yearLcalc;
	 document.getElementById("TLthreeL").innerHTML = per_threeLcalc;
	 }
	 	  if (znakcalc == "Bit") {
	 var cur_bitcalc = (+sum_calc / +pr_bitcalc).toFixed(8);
	 document.getElementById("txtDVSm").innerHTML = cur_bitcalc;
	 document.getElementById("TLDVSm").innerHTML = cur_bitcalc;
	 var per_mbitdogecalc = (+(+cur_bitcalc * +pr_dogecalc) / 3.2).toFixed(8);
	 var per_ybitdogecalc = (+per_mbitdogecalc * 12).toFixed(8);
	 var per_tbitdogecalc = (+per_ybitdogecalc *3).toFixed(8);
	 var per_dbitdogecalc = (+per_mbitdogecalc / 30).toFixed(8);
     var per_mbitclc = (+sum_calc / 3.2).toFixed(8);
     var per_ybitclc = (+per_mbitclc * 12).toFixed(8);
     var per_tbitclc =(+per_ybitclc * 3).toFixed(8);
     var per_dbitclc = (+per_mbitclc / 30).toFixed(8);
	 var per_mbitlitecalc = (+(+cur_bitcalc * +pr_litecalc) / 3.2).toFixed(8);
	 var per_ybitlitecalc = (+per_mbitlitecalc * 12).toFixed(8);
	 var per_tbitlitecalc = (+per_ybitlitecalc *3).toFixed(8);
	 var per_dbitlitecalc = (+per_mbitlitecalc / 30).toFixed(8);
	 document.getElementById("TLdayD").innerHTML = per_dbitdogecalc;
	 document.getElementById("TLmonthD").innerHTML = per_mbitdogecalc;
	 document.getElementById("TLyearD").innerHTML = per_ybitdogecalc;
	 document.getElementById("TLthreeD").innerHTML = per_tbitdogecalc;
     document.getElementById("TBitmonth").innerHTML = per_mbitclc;
     document.getElementById("TBityear").innerHTML = per_ybitclc;
     document.getElementById("TBthreey").innerHTML = per_tbitclc;
     document.getElementById("TBitday").innerHTML = per_dbitclc;
	 document.getElementById("TLdayL").innerHTML = per_dbitlitecalc;
	 document.getElementById("TLmonthL").innerHTML = per_mbitlitecalc;
	 document.getElementById("TLyearL").innerHTML = per_ybitlitecalc;
	 document.getElementById("TLthreeL").innerHTML = per_tbitlitecalc;
	 }
  }
        </script>
          <script type="text/javascript">
 function GetCalcm()
  {
  var sum_calcm = document.frmMultym.txtSumultym.value;
  var pr_bitcalcm = document.frmMultym.txtPrbm.value;
  var pr_dogecalcm = document.frmMultym.txtPrdm.value;
  var pr_litecalcm = document.frmMultym.txtPrlm.value;
  var selindcalcm = document.getElementById("slctCurrencym").options.selectedIndex;
  var txtcalcm= document.getElementById("slctCurrencym").options[selindcalcm].text;
  var valcalcm= document.getElementById("slctCurrencym").options[selindcalcm].value;
  var znakcalcm= document.getElementById("txtlabelvm").value = valcalcm;
   if (znakcalcm == "Doge") {
	 var cur_dogecalcm = (+sum_calcm / +pr_dogecalcm).toFixed(8);
	  document.getElementById("txtDVSmm").innerHTML = cur_dogecalcm;
	  document.getElementById("TLDVSmm").innerHTML = cur_dogecalcm;
	 var per_monthcalcm = (+sum_calcm /3.1).toFixed(8);
	 var per_yearcalcm = (+per_monthcalcm * 12).toFixed(8);
	 var per_threecalcm = (+per_yearcalcm * 3).toFixed(8);
	 var per_daycalcm = (+per_monthcalcm / 30).toFixed(8);
     var per_bitmonthclcm = (+(+cur_dogecalcm * +pr_bitcalcm) / 3.1).toFixed(8);
     var per_bityclcm = (+per_bitmonthclcm * 12).toFixed(8);
     var per_bittclcm = (+per_bityclcm * 3).toFixed(8);
     var per_bitdclcm = (+per_bitmonthclcm / 30).toFixed(8);
	 var per_lmcalcm = (+(+cur_dogecalcm * +pr_litecalcm) / 3.1).toFixed(8);
	 var per_lycalcm = (+per_lmcalcm * 12).toFixed(8);
	 var per_ltcalcm = (+per_lycalcm *3).toFixed(8);
	 var per_ldcalcm = (+per_lmcalcm / 30).toFixed(8);
	 document.getElementById("TLdayDm").innerHTML = per_daycalcm;
	 document.getElementById("TLmonthDm").innerHTML = per_monthcalcm;
	 document.getElementById("TLyearDm").innerHTML = per_yearcalcm;
	 document.getElementById("TLthreeDm").innerHTML = per_threecalcm;
     document.getElementById("TBitmonthm").innerHTML = per_bitmonthclcm;
     document.getElementById("TBityearm").innerHTML = per_bityclcm;
     document.getElementById("TBthreeym").innerHTML = per_bittclcm;
     document.getElementById("TBitdaym").innerHTML = per_bitdclcm;
	  document.getElementById("TLdayLm").innerHTML = per_ldcalcm;
	 document.getElementById("TLmonthLm").innerHTML = per_lmcalcm;
	 document.getElementById("TLyearLm").innerHTML = per_lycalcm;
	 document.getElementById("TLthreeLm").innerHTML = per_ltcalcm;
	 }
	  if (znakcalcm == "Lite") {
	 var cur_litecalcm = (+sum_calcm / +pr_litecalcm).toFixed(8);
	  document.getElementById("txtDVSmm").innerHTML = cur_litecalcm;
	  document.getElementById("TLDVSmm").innerHTML = cur_litecalcm;
     var per_dmcalcm = (+(+cur_litecalcm * +pr_dogecalcm) / 3.1).toFixed(8);
	 var per_dycalcm = (+per_dmcalcm * 12).toFixed(8);
	 var per_dtcalcm = (+per_dycalcm *3).toFixed(8);
	 var per_ddcalcm = (+per_dmcalcm / 30).toFixed(8);
     var per_bitmliclcm = (+(+cur_litecalcm * +pr_bitcalcm) / 3.1).toFixed(8);
     var per_bityliclcm = (+per_bitmliclcm * 12).toFixed(8);
     var per_bittliclcm = (+per_bityliclcm * 3).toFixed(8);
     var per_bitdliclcm = (+per_bitmliclcm / 30).toFixed(8);
     var per_monthLcalcm = (+sum_calcm /3.1).toFixed(8);
	 var per_yearLcalcm = (+per_monthLcalcm * 12).toFixed(8);
	 var per_threeLcalcm = (+per_yearLcalcm * 3).toFixed(8);
	 var per_dayLcalcm = (per_monthLcalcm / 30).toFixed(8);
     document.getElementById("TLdayDm").innerHTML = per_ddcalcm;
	 document.getElementById("TLmonthDm").innerHTML = per_dmcalcm;
	 document.getElementById("TLyearDm").innerHTML = per_dycalcm;
	 document.getElementById("TLthreeDm").innerHTML = per_dtcalcm;
     document.getElementById("TBitmonthm").innerHTML = per_bitmliclcm;
     document.getElementById("TBityearm").innerHTML = per_bityliclcm;
     document.getElementById("TBthreeym").innerHTML = per_bittliclcm;
     document.getElementById("TBitdaym").innerHTML = per_bitdliclcm;
	 document.getElementById("TLdayLm").innerHTML = per_dayLcalcm;
	 document.getElementById("TLmonthLm").innerHTML = per_monthLcalcm;
	 document.getElementById("TLyearLm").innerHTML = per_yearLcalcm;
	 document.getElementById("TLthreeLm").innerHTML = per_threeLcalcm;
	 }
	 	  if (znakcalcm == "Bit") {
	 var cur_bitcalcm = (+sum_calcm / +pr_bitcalcm).toFixed(8);
	 document.getElementById("txtDVSmm").innerHTML = cur_bitcalcm;
	 document.getElementById("TLDVSmm").innerHTML = cur_bitcalcm;
	 var per_mbitdogecalcm = (+(+cur_bitcalcm * +pr_dogecalcm) / 3.1).toFixed(8);
	 var per_ybitdogecalcm = (+per_mbitdogecalcm * 12).toFixed(8);
	 var per_tbitdogecalcm = (+per_ybitdogecalcm *3).toFixed(8);
	 var per_dbitdogecalcm = (+per_mbitdogecalcm / 30).toFixed(8);
     var per_mbitclcm = (+sum_calcm / 3.1).toFixed(8);
     var per_ybitclcm = (+per_mbitclcm * 12).toFixed(8);
     var per_tbitclcm =(+per_ybitclcm * 3).toFixed(8);
     var per_dbitclcm = (+per_mbitclcm / 30).toFixed(8);
	 var per_mbitlitecalcm = (+(+cur_bitcalcm * +pr_litecalcm) / 3.1).toFixed(8);
	 var per_ybitlitecalcm = (+per_mbitlitecalcm * 12).toFixed(8);
	 var per_tbitlitecalcm = (+per_ybitlitecalcm *3).toFixed(8);
	 var per_dbitlitecalcm = (+per_mbitlitecalcm / 30).toFixed(8);
	 document.getElementById("TLdayDm").innerHTML = per_dbitdogecalcm;
	 document.getElementById("TLmonthDm").innerHTML = per_mbitdogecalcm;
	 document.getElementById("TLyearDm").innerHTML = per_ybitdogecalcm;
	 document.getElementById("TLthreeDm").innerHTML = per_tbitdogecalcm;
     document.getElementById("TBitmonthm").innerHTML = per_mbitclcm;
     document.getElementById("TBityearm").innerHTML = per_ybitclcm;
     document.getElementById("TBthreeym").innerHTML = per_tbitclcm;
     document.getElementById("TBitdaym").innerHTML = per_dbitclcm;
	 document.getElementById("TLdayLm").innerHTML = per_dbitlitecalcm;
	 document.getElementById("TLmonthLm").innerHTML = per_mbitlitecalcm;
	 document.getElementById("TLyearLm").innerHTML = per_ybitlitecalcm;
	 document.getElementById("TLthreeLm").innerHTML = per_tbitlitecalcm;
	 }
  }
        </script>
 <script type="text/javascript">
 function GetCalcBIT()
 {
  var sum_calcdvs = document.formBuy.textfield.value;
  var pr_bitcalcdvs = document.formBuy.txtPrbDVS.value;
  var znakcalcdvs= document.getElementById("txtlabelvDVS").value = "Bitc";
     if (znakcalcdvs == "Bitc") {
	 var cur_bitcalcdvs = (+sum_calcdvs / +pr_bitcalcdvs).toFixed(8);
	 document.getElementById("txtDVSDVS").innerHTML = cur_bitcalcdvs;
	 document.getElementById("TLDVSDVS").innerHTML = cur_bitcalcdvs;
     var per_mbitclcdvs = (+sum_calcdvs / 2.9).toFixed(8);
     var per_ybitclcdvs = (+per_mbitclcdvs * 12).toFixed(8);
     var per_tbitclcdvs =(+per_ybitclcdvs * 3).toFixed(8);
     var per_dbitclcdvs = (+per_mbitclcdvs / 30).toFixed(8);
     document.getElementById("TBitmonthDVS").innerHTML = per_mbitclcdvs;
     document.getElementById("TBityearDVS").innerHTML = per_ybitclcdvs;
     document.getElementById("TBthreeyDVS").innerHTML = per_tbitclcdvs;
     document.getElementById("TBitdayDVS").innerHTML = per_dbitclcdvs;
	 }
 }
 </script>
</body>
</html>