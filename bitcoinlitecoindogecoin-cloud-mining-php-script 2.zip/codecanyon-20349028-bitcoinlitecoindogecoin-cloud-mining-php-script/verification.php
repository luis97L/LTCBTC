<!DOCTYPE HTML>
<html>
	<head>
		<title>TCC</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
	</head>

  <body>
<?php
    include_once("bdl.php");
    if (isset($_POST['submit'])){
		if(empty($_POST['login']))  {
			echo '<br><font color="red"><img border="0" src="error.gif" align="middle" alt="Enter login!"> Enter login! </font>';
		} 
		elseif (!preg_match("/^\w{3,}$/", $_POST['login'])) {
             include_once("main.html");
             echo "<script>alert(\"In the Login entered invalid characters! Only letters, numbers and underscore!"."\");</script>";
             exit;
        }
		elseif(empty($_POST['password'])) {
			echo '<br><font color="red"><img border="0" src="error.gif" align="middle" alt="Enter password !"> Enter password!</font>';
		}
		elseif (!preg_match("/\A(\w){6,20}\Z/", $_POST['password'])) {
            include_once("main.html");
             echo "<script>alert(\"Password is too short! The password must be at least 6 characters!"."\");</script>";
             exit;
        }
		elseif(empty($_POST['password2'])) {
			echo '<br><font color="red"><img border="0" src="error.gif" align="middle" alt="Enter the password confirmation!"> Enter the password confirmation!</font>';
		}
		elseif($_POST['password'] != $_POST['password2']) {
             include_once("main.html");
             echo "<script>alert(\"The entered passwords do not match!"."\");</script>";
             exit;
        }
		elseif(empty($_POST['email'])) {
			echo '<br><font color="red"><img border="0" src="error.gif" align="middle" alt="Enter E-mail!">Enter E-mail! </font>';
		}
		elseif (!preg_match("/^[a-zA-Z0-9_\.\-]+@([a-zA-Z0-9\-]+\.)+[a-zA-Z]{2,6}$/", $_POST['email'])) {
             include_once("main.html");
             echo "<script>alert(\"E-mail has an invalid format! For example, name@gmail.com!"."\");</script>";
             exit;
        }

		else{
		    $DBNEWUS = mysql_query("SELECT bnsB, bnsL, bnsD FROM costsmc WHERE id='1'");
            $aNEWUS = mysql_fetch_array($DBNEWUS) or die(mysql_error());
            $BNSbit = $aNEWUS['bnsB'];
            $BNSlite = $aNEWUS['bnsL'];
            $BNSdoge = $aNEWUS['bnsD'];
			$login = $_POST['login'];
			$password = $_POST['password'];
			$mdPassword = md5($password);
			$password2 = $_POST['password2'];
			$email = $_POST['email'];
			$rdate = date("d-m-Y  H:i");
			$name = $_POST['name'];
			$lastname = $_POST['lastname'];
			$ip = $_SERVER['REMOTE_ADDR'];
            $Activebez = "1";
			$cash = number_format($BNSbit,8,'.','');
			$dvs = "0.00000000";
			$MINING = "MINING";
			$MININGD = "MINING";
			$Depreg = "Please click on the button and generate a new address";
			$cashdoggy = number_format($BNSdoge,8,'.','');
			$cashlite = number_format($BNSlite,8,'.','');
			$Myref = md5($login);
			$dvsm = "0.00300000";
			$pros = "0.00000000";
            $mxdvs = "0.00000000";
			$query = ("SELECT id FROM gusers WHERE glogin='$login'");
			$sql = mysql_query($query) or die(mysql_error());
            $imageml = 'images/maileri.png';

			if (mysql_num_rows($sql) > 0) {
                 include_once("main.html");
             echo "<script>alert(\"User with such login registered!"."\");</script>";
             exit;
            }
			else {
				$query2 = ("SELECT id FROM gusers WHERE email='$email'");
				$sql = mysql_query($query2) or die(mysql_error());
				if (mysql_num_rows($sql) > 0){
             include_once("main.html");
             echo "<script>alert(\"User with this e-mail is registered!"."\");</script>";
             exit;
             }
				else{
	if(isset($_COOKIE['ref_id'])){
    $refrel = $_COOKIE['ref_id'];
	$rrefdate = date("d-m-Y  H:i");
	//-----------------------------------------------------------------------------
	$DBRefHIS = mysql_query("SELECT email,countref FROM greffer WHERE my_refflink='$refrel'");
    $RefHIS = mysql_fetch_array($DBRefHIS) or die(mysql_error());
	$hisidhis = $RefHIS['email'];
    $countmyref = $RefHIS['countref'];
    $countourmy = ($countmyref + 1);
    mysql_query("UPDATE greffer SET countref = '$countourmy' WHERE my_refflink='$refrel'");
	//-----------------------------------------------------------------------------
	$DBGUSHIS = mysql_query("SELECT id FROM gusers WHERE email='$hisidhis'");
    $GUSHIS = mysql_fetch_array($DBGUSHIS) or die(mysql_error());
	$hisgushis = $GUSHIS['id'];
	//-----------------------------------------------------------------------------
	$hisidmdhisl = md5($hisgushis);
	$hisidmdhis = $hisidmdhisl.".txt";
	$filehistref = 'histor/'.$hisidmdhis;
	$textref= $rrefdate." - "."new partner".'<br>';
    $text_1=file_get_contents($filehistref);
    $fdl=$textref.$text_1;
    $f_out = fopen($filehistref,"w");
    fwrite($f_out, $fdl);
    fclose($f_out);
	}
					$query = "INSERT INTO gusers (glogin, gpassword, email, reg_date, name_user, lastname,IP, activation, Cash, DVS, deposit, btnml, DVSbtmnl)
							  VALUES ('$login', '$mdPassword', '$email', '$rdate', '$name', '$lastname','$ip', '$Activebez','$cash', '$dvs', '$Depreg', '$MINING', '$MININGD')";
					$result = mysql_query($query) or die(mysql_error());;
					$query3 = "INSERT INTO ltcdoge (flogin, fpassword, email, activation, dogedeposit, Cashdoge, litedeposit, Cashlite, hisbit, hisdoge, hislite)
					            VALUES ('$login', '$mdPassword', '$email', '$Activebez', '$Depreg', '$cashdoggy', '$Depreg', '$cashlite', '$pros', '$pros', '$pros')";
					$result2 = mysql_query($query3) or die(mysql_error());;
					$query4 = "INSERT INTO ltcdogeming (vlogin, vpassword, email, activation, btndoge, btnltc,btndvs, DVSm)
					            VALUES ('$login', '$mdPassword', '$email', '$Activebez', '$MINING', '$MINING', '$MINING', '$dvsm' )";
					$result3 = mysql_query($query4) or die(mysql_error());;
					$query5 = "INSERT INTO greffer (rlogin, rrpassword, email, activation, reffer_id, my_refflink, name)
					             VALUES ('$login', '$mdPassword', '$email', '$Activebez','$refrel','$Myref', '$name')";
					$result4 = mysql_query($query5) or die(mysql_error());;
                    $query6 = "INSERT INTO gsmcnew (slogin, spassword, email, activation, mxdvs, mxbtmnl)
					             VALUES ('$login', '$mdPassword', '$email', '$Activebez', '$mxdvs','$MINING')";
					$result5 = mysql_query($query6) or die(mysql_error());;
					include_once("activvis.php");
					$activ = mysql_query ("SELECT id FROM gusers WHERE glogin='$login'");
					$id_activ = mysql_fetch_array($activ);
					$activation = md5($id_activ['id']);
                    $from = 'support@z-files.site';
                     $headerd = "From: \"Admin\" <admin@z-files.site>\n";
                    $headerd .= "Content-type: text/plain; charset=\"utf-8\"";
					$subject = "TCC Confirmation of registration";
					$message = "Hello! Thank you for registering on the site http://demo2.cryptodesign.xyz  Your login:".$login."\n
					Sincerely, Administration of this site http://demo2.cryptodesign.xyz/";
					mail($email, $subject, $message, $headerd);
        $connect = fsockopen ('127.0.0.1', 25, $errno, $errstr, 30);
        if(!$connect){
            echo json_encode($errno);
        } else {
            fputs($connect, "HELO localhost\r\n");
            fputs($connect, "MAIL FROM: $from\n");
            fputs($connect, "RCPT TO: $email\n");
            fputs($connect, "DATA\r\n");
            fputs($connect, "Content-Type: text/plain; charset=UTF-8");
            fputs($connect, "MIME-Version: 1.0\nContent-Transfer-Encoding: 7bit\n");
            fputs($connect, "To: $email\r\n");
            fputs($connect, "Subject: =?utf-8?b?".base64_encode($subject)."?=\r\n");
            fputs($connect, $message." \r\n");
            fputs($connect, ".\r\n");
            fputs($connect, "RSET\r\n");
        }
        fclose($connect);
				}
			}
		}
    }
?>
<style type="text/css">
<!--
body {
	font-size: 24px;
}
-->
</style>
</body>
</html>