<script type="text/javascript">
      var earn_month = 0;
      var doge_month = 0;
      var delay = 100;
      var delay_doge = 100;
      var cur_earn  = 0;
      var curdoge_earn  = 0;
      setInterval("startEarn()", delay);
      function startEarn() {
      var earn_earn = document.form3.txtsum.value;
      var eadn_eadn = document.form7.txtDogeSum.value;
      var earn_second = earn_month / 2592000;
      cur_earn += (earn_second * delay / 1000);
	  var earn_now = (+earn_earn + +cur_earn).toFixed(11);
      document.getElementById('labelcounted').innerHTML = earn_now;
      var doge_second = doge_month / (30 * 24 * 3600);
      curdoge_earn += (doge_second * delay / 1000);
	  var eadn_now = (+eadn_eadn + +curdoge_earn).toFixed(10);
      document.getElementById('labeldoge').innerHTML = eadn_now;
      }
      function updateEarn() {
      earn_month = document.form2.earn_month.value;
      cur_earn = earn_earn;
      doge_month = document.form6.earn_doge.value;
      curdoge_earn = eadn_eadn;
	  }
	  function stopEarn() {
	  earn_earn = 0;
      eadn_eadn = 0;
	  }
</script>